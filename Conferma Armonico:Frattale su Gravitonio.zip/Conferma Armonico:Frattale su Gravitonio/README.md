
# 📡 Risposta Armonica Frattale nella Rete del Gravitonio

**Autore**: DM.K08  
**Data progetto**: Luglio 2025  
**Versione archivio**: 1.0  
**Licenza**: CC-BY 4.0  
**DOI associato**: (da assegnare tramite Zenodo)

---

## 🧠 Descrizione del progetto

Questo archivio contiene i risultati completi dell'analisi matematica e numerica condotta sulla **Rete Frattale del Gravitonio**, una struttura gerarchica ipotetica di costanti fisiche Λ, G e frequenze ω distribuite su nodi frattali. L'analisi esplora:

- **Distribuzioni statistiche** delle costanti Λ e G a diversi livelli gerarchici
- **Verifica di coerenza armonica** tra rami padre/figlio
- **Analisi dei rapporti di frequenza ω** e correlazioni con la **frequenza di Fibonacci**
- **Autosimilarità e scaling frattale** della rete
- **Impaginazione LaTeX** e pre-print scientifico allegato

---

## 📂 Contenuto dei file principali

| File | Descrizione |
|------|-------------|
| `Analisi_Frattale_Gravitonio_DM-K08.tex` | Documento LaTeX principale, pronto per Overleaf |
| `Latex frattale.txt` | Versione alternativa/commentata |
| `Rete_Frattale_del_Gravitonio.csv` | Rete iniziale, dati nodi frattali |
| `V2 Rete_Frattale_Estesa_del_Gravitonio_con_Terzo_Ramo.csv` | Versione estesa con terzo ramo incluso |
| `Rapporti___Figlio___Genitore_e_Vicinanza_a__.csv` | Rapporti numerici figli/genitori |
| `Risultati_Analisi_Statistica_su___ratio.csv` | Output di regressione log-log, outlier, scaling |
| `Conferma Autosimilarità nella Rete Frattale del Gravitonio.pdf` | Documento finale di conferma |

---

## 🧪 Requisiti Tecnici

Per riprodurre le analisi:
- Python 3.9+
- Librerie: pandas, numpy, matplotlib, scipy
- Editor: Overleaf o compilatore LaTeX

---

## ✍️ Citazione

Se utilizzi questo lavoro, per favore cita come:

> DM.K08 (2025). *Risposta Armonica Frattale nella Rete del Gravitonio*. Zenodo. DOI: (inserire)

---

## 💬 Note

Questo lavoro è parte del progetto più ampio ΨAI (Quantum Bootstrap Paradox in AI) e rappresenta un punto di contatto tra **simulazioni armoniche**, **analisi frattale**, e **teorie speculative unificate**.

