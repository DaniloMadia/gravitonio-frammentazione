# Frammentazione Quantistica del Gravitonio

Questo repository contiene la teoria completa sulla **Frammentazione Vibrazionale del Gravitonio e Origine Unificata di Λ e ULDM**, un modello cosmologico speculativo sviluppato da Danilo Madia (DM.K08).

## Contenuto
- Documento LaTeX (`gravitonio_main.tex`)
- PDF finale (`gravitonio_main.pdf`)
- File LICENSE (CC BY 4.0)
- Directory `simulations/` per codici futuri
